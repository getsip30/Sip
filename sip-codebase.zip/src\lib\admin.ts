import { auth, clerkClient } from '@clerk/nextjs/server';

export async function isAdmin() {
  if (!process.env.ADMIN_EMAIL) return false;
  const { userId } = await auth();
  if (!userId) return false;
  const client = await clerkClient();
  const user = await client.users.getUser(userId);
  const email = user.emailAddresses[0]?.emailAddress;
  if (!email) return false;
  return email.toLowerCase() === process.env.ADMIN_EMAIL.toLowerCase();
}