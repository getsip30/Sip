'use client';
import { useEffect, useState } from 'react';
import { useUser } from '@clerk/nextjs';

export function useRoles() {
  const { user, isLoaded } = useUser();
  const [isMentor, setIsMentor] = useState(false);
  const [isSeeker, setIsSeeker] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!isLoaded) return;
    if (!user) { // eslint-disable-next-line react-hooks/set-state-in-effect
      setLoaded(true); return; }
    Promise.all([
      fetch('/api/mentor').then(r => r.ok ? r.json() : null).then(d => !!d),
      fetch('/api/seeker').then(r => r.ok ? r.json() : null).then(d => !!d),
    ]).then(([m, s]) => { setIsMentor(m); setIsSeeker(s); setLoaded(true); });
  }, [isLoaded, user]);

  return { isMentor, isSeeker, loaded };
}
