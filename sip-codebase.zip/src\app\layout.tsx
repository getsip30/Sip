﻿import { ClerkProvider } from '@clerk/nextjs';
import { dark } from '@clerk/themes';
import type { Metadata } from 'next';
import { ACCENT, BG } from '@/lib/theme';
import './globals.css';;

export const metadata: Metadata = {
  metadataBase: new URL('https://getsip.co'),
  title: {
    default: 'Sip — Find Your People',
    template: '%s | Sip',
  },
  description: 'Real conversations, zero cold messages. Sip connects you with mentors for live, no-pressure conversations — no scheduling, no cold outreach.',
  keywords: [
    'mentorship platform',
    'live mentorship',
    'find a mentor',
    'youth mentorship',
    'career conversations',
  ],
  icons: {
    icon: '/logo.png',
    shortcut: '/logo.png',
    apple: '/logo.png',
  },
  openGraph: {
    title: 'Sip — Find Your People',
    description: 'Real conversations, zero cold messages.',
    url: 'https://getsip.co',
    siteName: 'Sip',
    images: [
      {
        url: '/logo.png',
        width: 512,
        height: 512,
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Sip — Find Your People',
    description: 'Real conversations, zero cold messages.',
    images: ['/logo.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
    },
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider appearance={{
      theme: dark,
      variables: {
        colorPrimary: ACCENT,
        colorBackground: BG,
        borderRadius: '10px',
      },
    }}>
    <html lang="en">
        <head>
          <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />
        </head>
        <body>{children}</body>
      </html>
    </ClerkProvider>
  );
}